package androidx.arch.core.executor;

import java.util.concurrent.Executor;

public final class ArchTaskExecutor..ExternalSyntheticLambda0 implements Executor {
    @Override
    public final void execute(Runnable runnable0) {
        ArchTaskExecutor.lambda$static$0(runnable0);
    }
}

