package androidx.cardview;

public final class R {
    public static final class attr {
        public static final int cardBackgroundColor = 0x7F0400A3;  // attr:cardBackgroundColor
        public static final int cardCornerRadius = 0x7F0400A4;  // attr:cardCornerRadius
        public static final int cardElevation = 0x7F0400A5;  // attr:cardElevation
        public static final int cardMaxElevation = 0x7F0400A7;  // attr:cardMaxElevation
        public static final int cardPreventCornerOverlap = 0x7F0400A8;  // attr:cardPreventCornerOverlap
        public static final int cardUseCompatPadding = 0x7F0400A9;  // attr:cardUseCompatPadding
        public static final int cardViewStyle = 0x7F0400AA;  // attr:cardViewStyle
        public static final int contentPadding = 0x7F04014D;  // attr:contentPadding
        public static final int contentPaddingBottom = 0x7F04014E;  // attr:contentPaddingBottom
        public static final int contentPaddingLeft = 0x7F040150;  // attr:contentPaddingLeft
        public static final int contentPaddingRight = 0x7F040151;  // attr:contentPaddingRight
        public static final int contentPaddingTop = 0x7F040153;  // attr:contentPaddingTop

    }

    public static final class color {
        public static final int cardview_dark_background = 0x7F06002F;  // color:cardview_dark_background
        public static final int cardview_light_background = 0x7F060030;  // color:cardview_light_background
        public static final int cardview_shadow_end_color = 0x7F060031;  // color:cardview_shadow_end_color
        public static final int cardview_shadow_start_color = 0x7F060032;  // color:cardview_shadow_start_color

    }

    public static final class dimen {
        public static final int cardview_compat_inset_shadow = 0x7F070056;  // dimen:cardview_compat_inset_shadow
        public static final int cardview_default_elevation = 0x7F070057;  // dimen:cardview_default_elevation
        public static final int cardview_default_radius = 0x7F070058;  // dimen:cardview_default_radius

    }

    public static final class style {
        public static final int Base_CardView = 0x7F130011;  // style:Base.CardView
        public static final int CardView = 0x7F130121;  // style:CardView
        public static final int CardView_Dark = 0x7F130122;  // style:CardView.Dark
        public static final int CardView_Light = 0x7F130123;  // style:CardView.Light

    }

    public static final class styleable {
        public static final int[] CardView = null;
        public static final int CardView_android_minHeight = 1;
        public static final int CardView_android_minWidth = 0;
        public static final int CardView_cardBackgroundColor = 2;
        public static final int CardView_cardCornerRadius = 3;
        public static final int CardView_cardElevation = 4;
        public static final int CardView_cardMaxElevation = 5;
        public static final int CardView_cardPreventCornerOverlap = 6;
        public static final int CardView_cardUseCompatPadding = 7;
        public static final int CardView_contentPadding = 8;
        public static final int CardView_contentPaddingBottom = 9;
        public static final int CardView_contentPaddingLeft = 10;
        public static final int CardView_contentPaddingRight = 11;
        public static final int CardView_contentPaddingTop = 12;

        static {
            styleable.CardView = new int[]{0x101013F, 0x1010140, 0x7F0400A3, 0x7F0400A4, 0x7F0400A5, 0x7F0400A7, 0x7F0400A8, 0x7F0400A9, 0x7F04014D, 0x7F04014E, 0x7F040150, 0x7F040151, 0x7F040153};  // attr:cardBackgroundColor
        }
    }

}

