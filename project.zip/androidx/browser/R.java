package androidx.browser;

public final class R {
    public static final class color {
        public static final int browser_actions_bg_grey = 0x7F060027;  // color:browser_actions_bg_grey
        public static final int browser_actions_divider_color = 0x7F060028;  // color:browser_actions_divider_color
        public static final int browser_actions_text_color = 0x7F060029;  // color:browser_actions_text_color
        public static final int browser_actions_title_color = 0x7F06002A;  // color:browser_actions_title_color

    }

    public static final class dimen {
        public static final int browser_actions_context_menu_max_width = 0x7F070054;  // dimen:browser_actions_context_menu_max_width
        public static final int browser_actions_context_menu_min_padding = 0x7F070055;  // dimen:browser_actions_context_menu_min_padding

    }

    public static final class id {
        public static final int browser_actions_header_text = 0x7F09006B;  // id:browser_actions_header_text
        public static final int browser_actions_menu_item_icon = 0x7F09006C;  // id:browser_actions_menu_item_icon
        public static final int browser_actions_menu_item_text = 0x7F09006D;  // id:browser_actions_menu_item_text
        public static final int browser_actions_menu_items = 0x7F09006E;  // id:browser_actions_menu_items
        public static final int browser_actions_menu_view = 0x7F09006F;  // id:browser_actions_menu_view

    }

    public static final class layout {
        public static final int browser_actions_context_menu_page = 0x7F0C0020;  // layout:browser_actions_context_menu_page
        public static final int browser_actions_context_menu_row = 0x7F0C0021;  // layout:browser_actions_context_menu_row

    }

    public static final class string {
        public static final int copy_toast_msg = 0x7F12004C;  // string:copy_toast_msg "Link copied to clipboard"
        public static final int fallback_menu_item_copy_link = 0x7F120055;  // string:fallback_menu_item_copy_link "Copy link"
        public static final int fallback_menu_item_open_in_browser = 0x7F120056;  // string:fallback_menu_item_open_in_browser "Open in browser"
        public static final int fallback_menu_item_share_link = 0x7F120057;  // string:fallback_menu_item_share_link "Share link"

    }

    public static final class xml {
        public static final int image_share_filepaths = 0x7F150005;  // xml:image_share_filepaths

    }

}

