package androidx.appcompat.resources;

public final class R {
    public static final class drawable {
        public static final int abc_vector_test = 0x7F080077;  // drawable:abc_vector_test

    }

    public static final class styleable {
        public static final int[] AnimatedStateListDrawableCompat = null;
        public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
        public static final int AnimatedStateListDrawableCompat_android_dither = 0;
        public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
        public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
        public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
        public static final int AnimatedStateListDrawableCompat_android_visible = 1;
        public static final int[] AnimatedStateListDrawableItem = null;
        public static final int AnimatedStateListDrawableItem_android_drawable = 1;
        public static final int AnimatedStateListDrawableItem_android_id = 0;
        public static final int[] AnimatedStateListDrawableTransition = null;
        public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
        public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
        public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
        public static final int AnimatedStateListDrawableTransition_android_toId = 1;
        public static final int[] StateListDrawable = null;
        public static final int[] StateListDrawableItem = null;
        public static final int StateListDrawableItem_android_drawable = 0;
        public static final int StateListDrawable_android_constantSize = 3;
        public static final int StateListDrawable_android_dither = 0;
        public static final int StateListDrawable_android_enterFadeDuration = 4;
        public static final int StateListDrawable_android_exitFadeDuration = 5;
        public static final int StateListDrawable_android_variablePadding = 2;
        public static final int StateListDrawable_android_visible = 1;

        static {
            styleable.AnimatedStateListDrawableCompat = new int[]{0x101011C, 0x1010194, 0x1010195, 0x1010196, 0x101030C, 0x101030D};
            styleable.AnimatedStateListDrawableItem = new int[]{0x10100D0, 0x1010199};
            styleable.AnimatedStateListDrawableTransition = new int[]{0x1010199, 0x1010449, 0x101044A, 0x101044B};
            styleable.StateListDrawable = new int[]{0x101011C, 0x1010194, 0x1010195, 0x1010196, 0x101030C, 0x101030D};
            styleable.StateListDrawableItem = new int[]{0x1010199};
        }
    }

}

