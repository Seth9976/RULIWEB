package androidx.appcompat.widget;

public final class TooltipCompatHandler..ExternalSyntheticLambda1 implements Runnable {
    public final TooltipCompatHandler f$0;

    public TooltipCompatHandler..ExternalSyntheticLambda1(TooltipCompatHandler tooltipCompatHandler0) {
        this.f$0 = tooltipCompatHandler0;
    }

    @Override
    public final void run() {
        this.f$0.hide();
    }
}

