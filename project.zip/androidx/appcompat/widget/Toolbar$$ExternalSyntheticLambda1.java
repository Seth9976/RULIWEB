package androidx.appcompat.widget;

public final class Toolbar..ExternalSyntheticLambda1 implements Runnable {
    public final Toolbar f$0;

    public Toolbar..ExternalSyntheticLambda1(Toolbar toolbar0) {
        this.f$0 = toolbar0;
    }

    @Override
    public final void run() {
        this.f$0.invalidateMenu();
    }
}

