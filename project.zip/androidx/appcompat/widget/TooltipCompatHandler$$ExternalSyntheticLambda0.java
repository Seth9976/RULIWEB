package androidx.appcompat.widget;

public final class TooltipCompatHandler..ExternalSyntheticLambda0 implements Runnable {
    public final TooltipCompatHandler f$0;

    public TooltipCompatHandler..ExternalSyntheticLambda0(TooltipCompatHandler tooltipCompatHandler0) {
        this.f$0 = tooltipCompatHandler0;
    }

    @Override
    public final void run() {
        this.f$0.lambda$new$0$androidx-appcompat-widget-TooltipCompatHandler();
    }
}

