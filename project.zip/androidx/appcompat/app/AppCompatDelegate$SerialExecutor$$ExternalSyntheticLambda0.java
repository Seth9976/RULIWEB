package androidx.appcompat.app;

public final class AppCompatDelegate.SerialExecutor..ExternalSyntheticLambda0 implements Runnable {
    public final SerialExecutor f$0;
    public final Runnable f$1;

    public AppCompatDelegate.SerialExecutor..ExternalSyntheticLambda0(SerialExecutor appCompatDelegate$SerialExecutor0, Runnable runnable0) {
        this.f$0 = appCompatDelegate$SerialExecutor0;
        this.f$1 = runnable0;
    }

    @Override
    public final void run() {
        this.f$0.lambda$execute$0$androidx-appcompat-app-AppCompatDelegate$SerialExecutor(this.f$1);
    }
}

