package androidx.appcompat.app;

import android.content.Context;

public final class AppCompatDelegate..ExternalSyntheticLambda0 implements Runnable {
    public final Context f$0;

    public AppCompatDelegate..ExternalSyntheticLambda0(Context context0) {
        this.f$0 = context0;
    }

    @Override
    public final void run() {
        AppCompatDelegate.lambda$syncRequestedAndStoredLocales$1(this.f$0);
    }
}

