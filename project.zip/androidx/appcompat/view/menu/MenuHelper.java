package androidx.appcompat.view.menu;

interface MenuHelper {
    void dismiss();

    void setPresenterCallback(Callback arg1);
}

