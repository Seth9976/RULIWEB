package androidx.activity;

import android.content.Context;
import androidx.activity.contextaware.OnContextAvailableListener;

public final class ComponentActivity..ExternalSyntheticLambda4 implements OnContextAvailableListener {
    public final ComponentActivity f$0;

    public ComponentActivity..ExternalSyntheticLambda4(ComponentActivity componentActivity0) {
        this.f$0 = componentActivity0;
    }

    @Override  // androidx.activity.contextaware.OnContextAvailableListener
    public final void onContextAvailable(Context context0) {
        ComponentActivity._init_$lambda$5(this.f$0, context0);
    }
}

