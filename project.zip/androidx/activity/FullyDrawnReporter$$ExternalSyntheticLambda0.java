package androidx.activity;

public final class FullyDrawnReporter..ExternalSyntheticLambda0 implements Runnable {
    public final FullyDrawnReporter f$0;

    public FullyDrawnReporter..ExternalSyntheticLambda0(FullyDrawnReporter fullyDrawnReporter0) {
        this.f$0 = fullyDrawnReporter0;
    }

    @Override
    public final void run() {
        FullyDrawnReporter.reportRunnable$lambda$2(this.f$0);
    }
}

