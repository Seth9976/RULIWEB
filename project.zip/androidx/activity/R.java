package androidx.activity;

public final class R {
    public static final class id {
        public static final int report_drawn = 0x7F090191;  // id:report_drawn
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7F090226;  // id:view_tree_on_back_pressed_dispatcher_owner

    }

}

