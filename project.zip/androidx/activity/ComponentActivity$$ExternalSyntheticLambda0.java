package androidx.activity;

public final class ComponentActivity..ExternalSyntheticLambda0 implements Runnable {
    public final ComponentActivity f$0;

    public ComponentActivity..ExternalSyntheticLambda0(ComponentActivity componentActivity0) {
        this.f$0 = componentActivity0;
    }

    @Override
    public final void run() {
        ComponentActivity.menuHostHelper$lambda$0(this.f$0);
    }
}

