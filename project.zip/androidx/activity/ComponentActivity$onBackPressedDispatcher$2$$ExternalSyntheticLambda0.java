package androidx.activity;

public final class ComponentActivity.onBackPressedDispatcher.2..ExternalSyntheticLambda0 implements Runnable {
    public final ComponentActivity f$0;

    public ComponentActivity.onBackPressedDispatcher.2..ExternalSyntheticLambda0(ComponentActivity componentActivity0) {
        this.f$0 = componentActivity0;
    }

    @Override
    public final void run() {
        androidx.activity.ComponentActivity.onBackPressedDispatcher.2.invoke$lambda$0(this.f$0);
    }
}

