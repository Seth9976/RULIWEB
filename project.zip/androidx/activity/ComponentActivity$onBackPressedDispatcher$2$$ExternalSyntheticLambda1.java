package androidx.activity;

public final class ComponentActivity.onBackPressedDispatcher.2..ExternalSyntheticLambda1 implements Runnable {
    public final ComponentActivity f$0;
    public final OnBackPressedDispatcher f$1;

    public ComponentActivity.onBackPressedDispatcher.2..ExternalSyntheticLambda1(ComponentActivity componentActivity0, OnBackPressedDispatcher onBackPressedDispatcher0) {
        this.f$0 = componentActivity0;
        this.f$1 = onBackPressedDispatcher0;
    }

    @Override
    public final void run() {
        androidx.activity.ComponentActivity.onBackPressedDispatcher.2.invoke$lambda$2$lambda$1(this.f$0, this.f$1);
    }
}

