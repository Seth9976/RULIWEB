package androidx.activity;

public final class ComponentDialog..ExternalSyntheticLambda1 implements Runnable {
    public final ComponentDialog f$0;

    public ComponentDialog..ExternalSyntheticLambda1(ComponentDialog componentDialog0) {
        this.f$0 = componentDialog0;
    }

    @Override
    public final void run() {
        ComponentDialog.onBackPressedDispatcher$lambda$1(this.f$0);
    }
}

