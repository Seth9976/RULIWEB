package androidx.activity;

public final class ComponentActivity.ReportFullyDrawnExecutorImpl..ExternalSyntheticLambda0 implements Runnable {
    public final ReportFullyDrawnExecutorImpl f$0;

    public ComponentActivity.ReportFullyDrawnExecutorImpl..ExternalSyntheticLambda0(ReportFullyDrawnExecutorImpl componentActivity$ReportFullyDrawnExecutorImpl0) {
        this.f$0 = componentActivity$ReportFullyDrawnExecutorImpl0;
    }

    @Override
    public final void run() {
        ReportFullyDrawnExecutorImpl.execute$lambda$0(this.f$0);
    }
}

