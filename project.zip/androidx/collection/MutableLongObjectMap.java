package androidx.collection;

import kotlin.Metadata;
import kotlin.UByte..ExternalSyntheticBackport0;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0016\n\u0002\b\b\n\u0002\u0010\u000B\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u000F\u0012\b\b\u0002\u0010\u0003\u001A\u00020\u0004\u00A2\u0006\u0002\u0010\u0005J\b\u0010\u0007\u001A\u00020\bH\u0002J\u0006\u0010\t\u001A\u00020\bJ\u0010\u0010\n\u001A\u00020\u00042\u0006\u0010\u000B\u001A\u00020\fH\u0002J\u0010\u0010\r\u001A\u00020\u00042\u0006\u0010\u000E\u001A\u00020\u0004H\u0002J\'\u0010\u000F\u001A\u00028\u00002\u0006\u0010\u000B\u001A\u00020\f2\f\u0010\u0010\u001A\b\u0012\u0004\u0012\u00028\u00000\u0011H\u0086\b\u00F8\u0001\u0000\u00A2\u0006\u0002\u0010\u0012J\b\u0010\u0013\u001A\u00020\bH\u0002J\u0010\u0010\u0014\u001A\u00020\b2\u0006\u0010\u0015\u001A\u00020\u0004H\u0002J\u0010\u0010\u0016\u001A\u00020\b2\u0006\u0010\u0003\u001A\u00020\u0004H\u0002J\u0011\u0010\u0017\u001A\u00020\b2\u0006\u0010\u0018\u001A\u00020\u0019H\u0086\nJ\u0011\u0010\u0017\u001A\u00020\b2\u0006\u0010\u0018\u001A\u00020\u001AH\u0086\nJ\u0011\u0010\u0017\u001A\u00020\b2\u0006\u0010\u000B\u001A\u00020\fH\u0086\nJ\u0011\u0010\u0017\u001A\u00020\b2\u0006\u0010\u0018\u001A\u00020\u001BH\u0086\nJ\u0017\u0010\u001C\u001A\u00020\b2\f\u0010\u001D\u001A\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0086\nJ\u001D\u0010\u001E\u001A\u0004\u0018\u00018\u00002\u0006\u0010\u000B\u001A\u00020\f2\u0006\u0010\u001F\u001A\u00028\u0000\u00A2\u0006\u0002\u0010 J\u0014\u0010!\u001A\u00020\b2\f\u0010\u001D\u001A\b\u0012\u0004\u0012\u00028\u00000\u0002J\u0015\u0010\"\u001A\u0004\u0018\u00018\u00002\u0006\u0010\u000B\u001A\u00020\f\u00A2\u0006\u0002\u0010#J\u001B\u0010\"\u001A\u00020$2\u0006\u0010\u000B\u001A\u00020\f2\u0006\u0010\u001F\u001A\u00028\u0000\u00A2\u0006\u0002\u0010%J\b\u0010&\u001A\u00020\bH\u0002J&\u0010\'\u001A\u00020\b2\u0018\u0010(\u001A\u0014\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020$0)H\u0086\b\u00F8\u0001\u0000J\u0017\u0010*\u001A\u0004\u0018\u00018\u00002\u0006\u0010+\u001A\u00020\u0004H\u0001\u00A2\u0006\u0002\u0010,J\u0010\u0010-\u001A\u00020\b2\u0006\u0010.\u001A\u00020\u0004H\u0002J\u001E\u0010/\u001A\u00020\b2\u0006\u0010\u000B\u001A\u00020\f2\u0006\u0010\u001F\u001A\u00028\u0000H\u0086\u0002\u00A2\u0006\u0002\u00100J\u0006\u00101\u001A\u00020\u0004J\u0019\u00102\u001A\u00020\b2\u0006\u0010+\u001A\u00020\u00042\u0006\u0010\u001F\u001A\u00020\fH\u0082\bR\u000E\u0010\u0006\u001A\u00020\u0004X\u0082\u000E\u00A2\u0006\u0002\n\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001\u00A8\u00063"}, d2 = {"Landroidx/collection/MutableLongObjectMap;", "V", "Landroidx/collection/LongObjectMap;", "initialCapacity", "", "(I)V", "growthLimit", "adjustStorage", "", "clear", "findAbsoluteInsertIndex", "key", "", "findFirstAvailableSlot", "hash1", "getOrPut", "defaultValue", "Lkotlin/Function0;", "(JLkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "initializeGrowth", "initializeMetadata", "capacity", "initializeStorage", "minusAssign", "keys", "Landroidx/collection/LongList;", "Landroidx/collection/LongSet;", "", "plusAssign", "from", "put", "value", "(JLjava/lang/Object;)Ljava/lang/Object;", "putAll", "remove", "(J)Ljava/lang/Object;", "", "(JLjava/lang/Object;)Z", "removeDeletedMarkers", "removeIf", "predicate", "Lkotlin/Function2;", "removeValueAt", "index", "(I)Ljava/lang/Object;", "resizeStorage", "newCapacity", "set", "(JLjava/lang/Object;)V", "trim", "writeMetadata", "collection"}, k = 1, mv = {1, 8, 0}, xi = 0x30)
public final class MutableLongObjectMap extends LongObjectMap {
    private int growthLimit;

    public MutableLongObjectMap() {
        this(0, 1, null);
    }

    public MutableLongObjectMap(int v) {
        super(null);
        if(v < 0) {
            throw new IllegalArgumentException("Capacity must be a positive value.");
        }
        this.initializeStorage(ScatterMapKt.unloadedCapacity(v));
    }

    public MutableLongObjectMap(int v, int v1, DefaultConstructorMarker defaultConstructorMarker0) {
        if((v1 & 1) != 0) {
            v = 6;
        }
        this(v);
    }

    private final void adjustStorage() {
        if(this._capacity > 8 && UByte..ExternalSyntheticBackport0.m(((long)this._size) * 0x20L, ((long)this._capacity) * 25L) <= 0) {
            this.removeDeletedMarkers();
            return;
        }
        this.resizeStorage(ScatterMapKt.nextCapacity(this._capacity));
    }

    public final void clear() {
        this._size = 0;
        if(this.metadata != ScatterMapKt.EmptyGroup) {
            ArraysKt.fill$default(this.metadata, 0x8080808080808080L, 0, 0, 6, null);
            int v = this._capacity >> 3;
            this.metadata[v] |= 0xFFL << ((this._capacity & 7) << 3);
        }
        ArraysKt.fill(this.values, null, 0, this._capacity);
        this.initializeGrowth();
    }

    private final int findAbsoluteInsertIndex(long v) {
        int v1 = (int)(v ^ v >>> 0x20);
        int v2 = v1 * 0xCC9E2D51 ^ v1 * 0xCC9E2D51 << 16;
        int v3 = this._capacity;
        int v4 = v2 >>> 7 & v3;
        int v5 = 0;
        while(true) {
            int v6 = (v4 & 7) << 3;
            long v7 = this.metadata[(v4 >> 3) + 1] << 0x40 - v6 & -((long)v6) >> 0x3F | this.metadata[v4 >> 3] >>> v6;
            long v8 = v7 ^ ((long)(v2 & 0x7F)) * 0x101010101010101L;
            for(long v9 = ~v8 & v8 - 0x101010101010101L & 0x8080808080808080L; v9 != 0L; v9 &= v9 - 1L) {
                int v10 = (Long.numberOfTrailingZeros(v9) >> 3) + v4 & v3;
                if(this.keys[v10] == v) {
                    return v10;
                }
            }
            if((~v7 << 6 & v7 & 0x8080808080808080L) != 0L) {
                int v11 = this.findFirstAvailableSlot(v2 >>> 7);
                if(this.growthLimit == 0 && (this.metadata[v11 >> 3] >> ((v11 & 7) << 3) & 0xFFL) != 0xFEL) {
                    this.adjustStorage();
                    v11 = this.findFirstAvailableSlot(v2 >>> 7);
                }
                ++this._size;
                int v12 = (v11 & 7) << 3;
                this.growthLimit -= ((this.metadata[v11 >> 3] >> v12 & 0xFFL) == 0x80L ? 1 : 0);
                long[] arr_v = this.metadata;
                arr_v[v11 >> 3] = arr_v[v11 >> 3] & ~(0xFFL << v12) | ((long)(v2 & 0x7F)) << v12;
                int v13 = (v11 - 7 & this._capacity) + (this._capacity & 7);
                int v14 = (v13 & 7) << 3;
                arr_v[v13 >> 3] = ~(0xFFL << v14) & arr_v[v13 >> 3] | ((long)(v2 & 0x7F)) << v14;
                return v11;
            }
            v5 += 8;
            v4 = v4 + v5 & v3;
        }
    }

    private final int findFirstAvailableSlot(int v) {
        long v6;
        int v1 = this._capacity;
        int v2 = v & v1;
        int v3 = 0;
        while(true) {
            int v4 = (v2 & 7) << 3;
            long v5 = this.metadata[(v2 >> 3) + 1] << 0x40 - v4 & -((long)v4) >> 0x3F | this.metadata[v2 >> 3] >>> v4;
            v6 = v5 & ~v5 << 7 & 0x8080808080808080L;
            if(v6 != 0L) {
                break;
            }
            v3 += 8;
            v2 = v2 + v3 & v1;
        }
        return v2 + (Long.numberOfTrailingZeros(v6) >> 3) & v1;
    }

    public final Object getOrPut(long v, Function0 function00) {
        Intrinsics.checkNotNullParameter(function00, "defaultValue");
        Object object0 = this.get(v);
        if(object0 == null) {
            Object object1 = function00.invoke();
            this.set(v, object1);
            return object1;
        }
        return object0;
    }

    private final void initializeGrowth() {
        this.growthLimit = ScatterMapKt.loadedCapacity(this.getCapacity()) - this._size;
    }

    private final void initializeMetadata(int v) {
        long[] arr_v;
        if(v == 0) {
            arr_v = ScatterMapKt.EmptyGroup;
        }
        else {
            long[] arr_v1 = new long[(v + 15 & -8) >> 3];
            ArraysKt.fill$default(arr_v1, 0x8080808080808080L, 0, 0, 6, null);
            arr_v = arr_v1;
        }
        this.metadata = arr_v;
        this.metadata[v >> 3] |= 0xFFL << ((v & 7) << 3);
        this.initializeGrowth();
    }

    private final void initializeStorage(int v) {
        int v1 = v <= 0 ? 0 : Math.max(7, ScatterMapKt.normalizeCapacity(v));
        this._capacity = v1;
        this.initializeMetadata(v1);
        this.keys = new long[v1];
        this.values = new Object[v1];
    }

    public final void minusAssign(long v) {
        this.remove(v);
    }

    public final void minusAssign(LongList longList0) {
        Intrinsics.checkNotNullParameter(longList0, "keys");
        long[] arr_v = longList0.content;
        int v = longList0._size;
        for(int v1 = 0; v1 < v; ++v1) {
            this.remove(arr_v[v1]);
        }
    }

    public final void minusAssign(LongSet longSet0) {
        Intrinsics.checkNotNullParameter(longSet0, "keys");
        long[] arr_v = longSet0.elements;
        long[] arr_v1 = longSet0.metadata;
        int v = arr_v1.length - 2;
        if(v >= 0) {
            int v1 = 0;
            while(true) {
                long v2 = arr_v1[v1];
                if((~v2 << 7 & v2 & 0x8080808080808080L) != 0x8080808080808080L) {
                    int v3 = 8 - (~(v1 - v) >>> 0x1F);
                    for(int v4 = 0; v4 < v3; ++v4) {
                        if((0xFFL & v2) < 0x80L) {
                            this.remove(arr_v[(v1 << 3) + v4]);
                        }
                        v2 >>= 8;
                    }
                    if(v3 == 8) {
                        goto label_17;
                    }
                    break;
                }
            label_17:
                if(v1 == v) {
                    break;
                }
                ++v1;
            }
        }
    }

    public final void minusAssign(long[] arr_v) {
        Intrinsics.checkNotNullParameter(arr_v, "keys");
        for(int v = 0; v < arr_v.length; ++v) {
            this.remove(arr_v[v]);
        }
    }

    public final void plusAssign(LongObjectMap longObjectMap0) {
        Intrinsics.checkNotNullParameter(longObjectMap0, "from");
        this.putAll(longObjectMap0);
    }

    public final Object put(long v, Object object0) {
        int v1 = this.findAbsoluteInsertIndex(v);
        Object object1 = this.values[v1];
        this.keys[v1] = v;
        this.values[v1] = object0;
        return object1;
    }

    public final void putAll(LongObjectMap longObjectMap0) {
        Intrinsics.checkNotNullParameter(longObjectMap0, "from");
        long[] arr_v = longObjectMap0.keys;
        Object[] arr_object = longObjectMap0.values;
        long[] arr_v1 = longObjectMap0.metadata;
        int v = arr_v1.length - 2;
        if(v >= 0) {
            int v1 = 0;
            while(true) {
                long v2 = arr_v1[v1];
                if((~v2 << 7 & v2 & 0x8080808080808080L) != 0x8080808080808080L) {
                    int v3 = 8 - (~(v1 - v) >>> 0x1F);
                    for(int v4 = 0; v4 < v3; ++v4) {
                        if((0xFFL & v2) < 0x80L) {
                            int v5 = (v1 << 3) + v4;
                            this.set(arr_v[v5], arr_object[v5]);
                        }
                        v2 >>= 8;
                    }
                    if(v3 == 8) {
                        goto label_19;
                    }
                    break;
                }
            label_19:
                if(v1 == v) {
                    break;
                }
                ++v1;
            }
        }
    }

    public final Object remove(long v) {
        int v1 = (int)(v ^ v >>> 0x20);
        int v2 = v1 * 0xCC9E2D51 ^ v1 * 0xCC9E2D51 << 16;
        int v3 = this._capacity;
        int v4 = v2 >>> 7 & v3;
        int v5 = 0;
        while(true) {
            int v6 = (v4 & 7) << 3;
            long v7 = this.metadata[(v4 >> 3) + 1] << 0x40 - v6 & -((long)v6) >> 0x3F | this.metadata[v4 >> 3] >>> v6;
            long v8 = ((long)(v2 & 0x7F)) * 0x101010101010101L ^ v7;
            for(long v9 = ~v8 & v8 - 0x101010101010101L & 0x8080808080808080L; v9 != 0L; v9 &= v9 - 1L) {
                int v10 = (Long.numberOfTrailingZeros(v9) >> 3) + v4 & v3;
                if(this.keys[v10] == v) {
                    return v10 < 0 ? null : this.removeValueAt(v10);
                }
            }
            if((v7 & ~v7 << 6 & 0x8080808080808080L) != 0L) {
                return null;
            }
            v5 += 8;
            v4 = v4 + v5 & v3;
        }
    }

    public final boolean remove(long v, Object object0) {
        int v11;
        int v1 = (int)(v ^ v >>> 0x20);
        int v2 = v1 * 0xCC9E2D51 ^ v1 * 0xCC9E2D51 << 16;
        int v3 = this._capacity;
        int v4 = v2 >>> 7 & v3;
        int v5 = 0;
        while(true) {
            int v6 = (v4 & 7) << 3;
            long v7 = this.metadata[(v4 >> 3) + 1] << 0x40 - v6 & -((long)v6) >> 0x3F | this.metadata[v4 >> 3] >>> v6;
            long v8 = ((long)(v2 & 0x7F)) * 0x101010101010101L ^ v7;
            long v9 = ~v8 & v8 - 0x101010101010101L & 0x8080808080808080L;
            while(v9 != 0L) {
                int v10 = (Long.numberOfTrailingZeros(v9) >> 3) + v4 & v3;
                if(this.keys[v10] == v) {
                    v11 = v10;
                    goto label_18;
                }
                v9 &= v9 - 1L;
            }
            if((v7 & ~v7 << 6 & 0x8080808080808080L) == 0L) {
                goto label_22;
            }
            else {
                v11 = -1;
            }
        label_18:
            if(v11 >= 0 && Intrinsics.areEqual(this.values[v11], object0)) {
                this.removeValueAt(v11);
                return true;
            }
            return false;
        label_22:
            v5 += 8;
            v4 = v4 + v5 & v3;
        }
    }

    private final void removeDeletedMarkers() {
        long[] arr_v = this.metadata;
        int v = this._capacity;
        int v2 = 0;
        for(int v1 = 0; v1 < v; ++v1) {
            int v3 = (v1 & 7) << 3;
            if((arr_v[v1 >> 3] >> v3 & 0xFFL) == 0xFEL) {
                long[] arr_v1 = this.metadata;
                arr_v1[v1 >> 3] = 0x80L << v3 | arr_v1[v1 >> 3] & ~(0xFFL << v3);
                int v4 = (v1 - 7 & this._capacity) + (this._capacity & 7);
                int v5 = (v4 & 7) << 3;
                arr_v1[v4 >> 3] = ~(0xFFL << v5) & arr_v1[v4 >> 3] | 0x80L << v5;
                ++v2;
            }
        }
        this.growthLimit += v2;
    }

    public final void removeIf(Function2 function20) {
        Intrinsics.checkNotNullParameter(function20, "predicate");
        long[] arr_v = this.metadata;
        int v = arr_v.length - 2;
        if(v >= 0) {
            int v1 = 0;
            while(true) {
                long v2 = arr_v[v1];
                if((~v2 << 7 & v2 & 0x8080808080808080L) != 0x8080808080808080L) {
                    int v3 = 8 - (~(v1 - v) >>> 0x1F);
                    for(int v4 = 0; v4 < v3; ++v4) {
                        if((0xFFL & v2) < 0x80L) {
                            int v5 = (v1 << 3) + v4;
                            if(((Boolean)function20.invoke(((long)this.keys[v5]), this.values[v5])).booleanValue()) {
                                this.removeValueAt(v5);
                            }
                        }
                        v2 >>= 8;
                    }
                    if(v3 == 8) {
                        goto label_18;
                    }
                    break;
                }
            label_18:
                if(v1 == v) {
                    break;
                }
                ++v1;
            }
        }
    }

    public final Object removeValueAt(int v) {
        --this._size;
        long[] arr_v = this.metadata;
        int v1 = (v & 7) << 3;
        arr_v[v >> 3] = arr_v[v >> 3] & ~(0xFFL << v1) | 0xFEL << v1;
        int v2 = (v - 7 & this._capacity) + (this._capacity & 7);
        int v3 = (v2 & 7) << 3;
        arr_v[v2 >> 3] = arr_v[v2 >> 3] & ~(0xFFL << v3) | 0xFEL << v3;
        Object object0 = this.values[v];
        this.values[v] = null;
        return object0;
    }

    private final void resizeStorage(int v) {
        long[] arr_v = this.metadata;
        long[] arr_v1 = this.keys;
        Object[] arr_object = this.values;
        int v1 = this._capacity;
        this.initializeStorage(v);
        long[] arr_v2 = this.keys;
        Object[] arr_object1 = this.values;
        for(int v2 = 0; v2 < v1; ++v2) {
            if((arr_v[v2 >> 3] >> ((v2 & 7) << 3) & 0xFFL) < 0x80L) {
                long v3 = arr_v1[v2];
                int v4 = (int)(v3 ^ v3 >>> 0x20);
                int v5 = v4 * 0xCC9E2D51 ^ v4 * 0xCC9E2D51 << 16;
                int v6 = this.findFirstAvailableSlot(v5 >>> 7);
                long[] arr_v3 = this.metadata;
                int v7 = (v6 & 7) << 3;
                arr_v3[v6 >> 3] = arr_v3[v6 >> 3] & ~(0xFFL << v7) | ((long)(v5 & 0x7F)) << v7;
                int v8 = (v6 - 7 & this._capacity) + (this._capacity & 7);
                int v9 = (v8 & 7) << 3;
                arr_v3[v8 >> 3] = arr_v3[v8 >> 3] & ~(0xFFL << v9) | ((long)(v5 & 0x7F)) << v9;
                arr_v2[v6] = v3;
                arr_object1[v6] = arr_object[v2];
            }
        }
    }

    public final void set(long v, Object object0) {
        int v1 = this.findAbsoluteInsertIndex(v);
        this.keys[v1] = v;
        this.values[v1] = object0;
    }

    public final int trim() {
        int v = this._capacity;
        int v1 = ScatterMapKt.normalizeCapacity(ScatterMapKt.unloadedCapacity(this._size));
        if(v1 < v) {
            this.resizeStorage(v1);
            return v - this._capacity;
        }
        return 0;
    }

    private final void writeMetadata(int v, long v1) {
        long[] arr_v = this.metadata;
        int v2 = (v & 7) << 3;
        arr_v[v >> 3] = arr_v[v >> 3] & ~(0xFFL << v2) | v1 << v2;
        int v3 = (v - 7 & this._capacity) + (this._capacity & 7);
        int v4 = (v3 & 7) << 3;
        arr_v[v3 >> 3] = v1 << v4 | arr_v[v3 >> 3] & ~(0xFFL << v4);
    }
}

